def sumar(op1, op2):
    suma = op1 + op2
    print("El resultado de la suma es:", suma)

def restar(op1, op2):
    resta = op1 - op2
    print("El resultado de la resta es:", resta)

def multiplicar(op1, op2):
    multiplicacion = op1 * op2
    print("El resultado de multiplicacion:", multiplicacion)

def dividir(dividendo, divisor):
    divicion = dividendo / divisor
    print("El resultado de la divicion:", divicion)

def potencia(base, exponente):
    potencia = base ** exponente
    print("El resultado de la elevacion es:", exponente)

def redondear(numero):
    redondeo = round(numero)
    print("El resultado del redondeo es:", redondeo)
