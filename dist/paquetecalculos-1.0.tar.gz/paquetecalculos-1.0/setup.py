from setuptools import setup

setup(
    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Laloparkour",
    author_email="laloparkour@email.com",
    url="www.laloparkour.com",
    packages=["calculos","calculos.redondeo_potencia"]
)